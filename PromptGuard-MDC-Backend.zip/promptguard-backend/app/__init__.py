"""PromptGuard educational backend."""
